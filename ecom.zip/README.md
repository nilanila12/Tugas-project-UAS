# e-commerce

![alt text](img/e-commerce.png "image title")

Belajat PHP dasar dengan membuat toko online 'Gaya Distro'

1. Website ini dibuat dengan menggunakan bahasa pemograman:
  * PHP 7
  * CSS
  * HTML
  * Javascript

2. Untuk Databasenya bisa lihat di folder  db

Jika anda ingin melihat lebih jelas lagi silahkan klik [Disini](https://github.com/regaaji/e-commerce/)
